import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';
import jwt from 'jwt-simple';

// todo: store in env vars
const JWT_SECRET = 'fe1a1915a379f3be5394b64d14794932';

export const handler = async (event) => {
  const client = new SecretsManagerClient({
    region: process.env.AWS_REGION,
  });

  const response = await client.send(
    new GetSecretValueCommand({
      SecretId: process.env.SECRETS_STORAGE_NAME,
      VersionStage: 'AWSCURRENT',
    }),
  );

  const correctPassword = response.SecretString;

  const jwt = getJwt();
  const isJwtValid = validateJwt(jwt);

  return {
    isCorrectPassword: event.password === correctPassword,
    jwt,
    isJwtValid,
  };
};

function getJwt() {
  const payload = { userId: makeId() };
  return jwt.encode(payload, JWT_SECRET);
}

function makeId() {
  const length = 12;
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

function validateJwt(token) {
  try {
    return jwt.decode(token, JWT_SECRET);
  } catch {
    return false;
  }
}
